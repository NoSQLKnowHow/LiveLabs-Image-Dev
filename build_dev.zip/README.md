# AI Data Platform Development Environment

This is an **Oracle LiveLabs Custom Image Generator** - an infrastructure automation framework for provisioning preconfigured development environments on OCI with JupyterLab, Streamlit, Ollama LLM, and Oracle Database connectivity.

## Project Overview

**Purpose:** Automate setup and deployment of a fully functional AI/ML development environment for Oracle AI Data Platform workshops.

**Technology Stack:**
- Container Runtime: Podman/Podman Compose
- Base OS: Oracle Linux 9
- Languages: Bash, Python 3.11, Node.js 20, Java 21
- Frameworks: JupyterLab, Streamlit, Flask
- AI/ML: Ollama (LLM runtime), LangChain, Oracle AI Services
- Database: Oracle Autonomous Database (ADB), MongoDB, Oracle Graph DB

---

## Directory Structure

```
aidataplatform_dev_vscode/
├── inst.sh                    # Entry point: VM setup script (run first)
├── build_dev.zip              # Packaged build artifacts
├── README.md                  # User documentation
├── CLAUDE.md                  # AI assistant guidelines (this file)
│
├── ingestion/             # Container orchestration
│   ├── compose.yml            # Main Podman Compose definition
│   ├── dockerjupyter          # JupyterLab container Dockerfile
│   ├── dockerfiledemo         # Demo/Streamlit container Dockerfile
│   ├── dockerfileollama       # Ollama LLM container Dockerfile
│   ├── addon-docker-scripts/
│   │   └── entrypoint.sh      # Demo container startup script
│   ├── model/
│   │   ├── pull_ollama.sh     # Downloads LLaMA 3.2 model
│   │   └── load_model_2_db.sh # Loads models to database
│   ├── jl_config/             # JupyterLab settings
│   │   ├── jupyter_lab_config.py
│   │   └── lab/               # Workspace configs, themes
│   ├── vscode-config/         # VS Code settings
├── init/                      # Bootstrap scripts (run in order)
│   ├── bootstrap.sh           # Main orchestrator
│   ├── warmup.sh              # Download artifacts from OCI
│   ├── deployapp.sh           # Deploy app from Object Storage
│   ├── setenv.sh              # Generate .env files
│   ├── variable.sh            # Resolve vars from OCI metadata
│   ├── adb-wallet.sh          # Setup ADB wallet
│   ├── dbsetup.sh             # Initialize database
│   ├── firstboot.sh           # OCI hostname setup
│   ├── alias.sh               # CLI aliases
│   ├── demo.env               # Environment variable template
│   └── user-podman.service    # Systemd service for auto-start
│
└── addon/                     # Database SQL scripts
    └── readme.md
```

---

## Container Architecture

Three interconnected services defined in `compose.yml`:

| Service | Port(s) | Purpose |
|---------|---------|---------|
| `jupyterlab` | 8888, 8501, 8087, 8088 | Interactive notebooks, data science |
| `demo` | 5000, 8502 | Streamlit demo applications |
| `ollama` | 11434 | Local LLM inference (LLaMA 3.2) |

**Volume Mounts:**
- JupyterLab apps: `/home/opc/ingestion/app/lab/aidata_dev_vscode_privai` → container `/home/`
- Demo apps: `/home/opc/ingestion/app/demo/ai-data-platform` → container `/home/oracle/`
- Ollama models: `./model/` → container `/root/.ollama/`

---

## Bootstrap Workflow

Execution order when provisioning a new VM:

```
1. inst.sh (manual)          → Install packages, configure firewall, setup Podman
2. systemd starts bootstrap  → Triggers init scripts automatically
3. bootstrap.sh              → Orchestrates all init scripts:
   ├── warmup.sh             → Download build artifacts
   ├── deployapp.sh          → Clone/deploy application code
   ├── setenv.sh             → Generate environment configs
   ├── adb-wallet.sh         → Setup database wallet
   └── dbsetup.sh            → Run database initialization
```

---

## Key Files Reference

### Entry Points
| File | Description |
|------|-------------|
| `inst.sh` | Run first on fresh OCI VM - installs all dependencies |
| `init/bootstrap.sh` | Main orchestrator, runs all setup scripts |

### Dockerfiles
| File | Base Image | Key Components |
|------|------------|----------------|
| `ingestion/dockerjupyter` | Oracle Linux 9 | JupyterLab, Python data science stack, Oracle drivers |
| `ingestion/dockerfiledemo` | Oracle Linux 9 | Streamlit, Flask, AI provider SDKs |
| `ingestion/dockerfileollama` | Official Ollama | LLaMA 3.2 model server |

### Configuration
| File | Purpose |
|------|---------|
| `ingestion/compose.yml` | Podman Compose service definitions |
| `init/demo.env` | Template for required environment variables |
| `ingestion/jl_config/jupyter_lab_config.py` | JupyterLab server settings |
| `init/user-podman.service` | Systemd service for auto-start |

---

## Environment Variables

Required variables (set in `.env` or via OCI metadata):

### OCI Credentials
- `pem_key` - Private key content
- `user_ocid` - OCI user OCID
- `tenancy_ocid` - Tenancy OCID
- `compartment_ocid` - Compartment OCID
- `adb_ocid` - Autonomous Database OCID

### Database
- `dbconnection` - Full connection string
- `dbpassword` - Database password
- `dbname` - Database name
- `SERVICE_NAME` - Oracle service name
- `ordsurl` - ORDS endpoint URL

### External Services
- `mongodbapi` - MongoDB API endpoint
- `graphurl` - Oracle Graph endpoint
- `ai_endpoint_region` - OCI AI service region

---

## Development Workflow

### Local Development
1. Provision OCI VM with inst.sh
2. Provide `.env` file with credentials
3. Bootstrap starts containers automatically
4. Access JupyterLab: `http://<ip>:8888`
5. Access Demo apps: `http://<ip>:5000` or `:8502`
6. Edit code in mounted directories - changes reflect immediately

### Managing Services
```bash
# Check status
systemctl --user status user-podman

# Restart containers
systemctl --user restart user-podman

# View logs
podman-compose -f /home/opc/ingestion/compose.yml logs -f
```

---

## Conventions

### File Naming
- Dockerfiles: `dockerfile<service>` (lowercase, no extension)
- Init scripts: `<action>.sh` (verb-based: deploy, setup, warmup)
- Backup files: `.bak` suffix

### Environment Variables
- Uppercase for exports: `DBPASSWORD`, `BASEURL`
- Local variants: `dbconnectionlocal`
- OCI identifiers: `*_OCID` suffix

### Paths (on deployed VM)
- User home: `/home/opc/`
- Compose root: `/home/opc/ingestion/`
- App directories: `/home/opc/ingestion/app/{lab,demo}/`
- OCI credentials: `/home/opc/.oci/`
- Init scripts: `/home/opc/init/`

---

## Network Configuration

### Firewall Ports (configured by inst.sh)
| Port | Service |
|------|---------|
| 1521, 1522 | Oracle Database |
| 8888 | JupyterLab |
| 8501-8505 | Streamlit instances |
| 5000 | Flask |
| 11434 | Ollama API |
| 27017 | MongoDB |
| 8085-8088 | Spring Boot |

---

## AI Assistant Guidelines

### When Editing Scripts
- All shell scripts use bash with strict mode (`set -euo pipefail`)
- Maintain marker file patterns for idempotent runs (e.g., `/home/opc/init/.db_initialized`)
- Log to `/home/opc/bootstrap.log` for troubleshooting
- Always provide fallback values when reading from OCI metadata

### When Editing Dockerfiles
- Base all containers on Oracle Linux 9 for consistency
- Use `microdnf` for package installation (not `dnf` or `yum`)
- Install Python packages with `pip3.11` specifically
- Preserve the volume mount points for app persistence

### When Editing Compose
- Keep restart policy as `always` for production stability
- Maintain environment variable passthrough from host
- Preserve port mappings for documented services

### Security Considerations
- Credentials are stored in `.env` files and `~/.oci/`
- No secrets management system is in place - handle with care
- Private keys must have restricted permissions (600)
- Never commit `.env` files or private keys

### Testing Changes
1. Test scripts locally with a mock `.env` file first
2. Use `bash -n script.sh` to syntax-check without running
3. For Dockerfile changes, build with `podman build -f <dockerfile> .`
4. For compose changes, validate with `podman-compose config`
